<?php
class ModelExtensionPaymentEpoint extends Model {
	public function getMethod($address, $total) {
		$this->load->language('extension/payment/epoint');

		if ($total >= 0.01) {
			$status = true;
		} else {
			$status = false;
		}

		$method_data = array();

		if ($status) {
			$method_data = array(
				'code'       => 'epoint',
				'title'      => $this->language->get('text_title'),
				'terms'      => '',
				'sort_order' => $this->config->get('payment_epoint_sort_order')
			);
		}

		return $method_data;
	}
}
?>