<?php
// Text
$_['text_title'] = 'Epoint.az';
?>
