<?php
class ModelExtensionPaymentEpoint extends Model {
}