<?php
namespace Opencart\Catalog\Model\Extension\Epoint\Payment;
class Epoint extends \Opencart\System\Engine\Model {
	public function getMethod(array $address, float $total = 0.0):array {
		$this->load->language('extension/epoint/payment/epoint');

		$method_data = [];

			$method_data = [
				'code'       => 'epoint',
				'title'      => $this->language->get('text_title'),
				'terms'      => '',
				'sort_order' => $this->config->get('payment_epoint_sort_order')
			];

		return $method_data;
	}
}
?>