<?php
// Text
$_['heading_title'] = 'Epoint.az';
$_['text_title'] = 'Epoint.az';
?>
