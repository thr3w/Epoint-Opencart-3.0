<?php
namespace Opencart\Admin\Controller\Extension\Epoint\Payment;
class Epoint extends \Opencart\System\Engine\Controller {
	private $error = array();
	private $currencies = array('AZN');
	public function index():void {
		$this->load->language('extension/epoint/payment/epoint');

		$this->document->setTitle($this->language->get('heading_title'));


		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['error_public_key'])) {
			$data['error_public_key'] = $this->error['error_public_key'];
		} else {
			$data['error_public_key'] = '';
		}

		if (isset($this->error['error_private_key'])) {
			$data['error_private_key'] = $this->error['error_private_key'];
		} else {
			$data['error_private_key'] = '';
		}

		if (isset($this->error['error_currency'])) {
			$data['error_currency'] = $this->error['error_currency'];
		} else {
			$data['error_currency'] = '';
		}



		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/epoint/payment/epoint', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['save'] = $this->url->link('extension/epoint/payment/epoint|save', 'user_token=' . $this->session->data['user_token']);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment');


		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);
		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

$data['payment_epoint_public_key'] = $this->config->get('payment_epoint_public_key');
$data['payment_epoint_private_key'] = $this->config->get('payment_epoint_private_key');
$data['payment_epoint_language'] = $this->config->get('payment_epoint_language');
$data['payment_epoint_currency'] = $this->config->get('payment_epoint_currency');
$data['payment_epoint_order_status_id'] = $this->config->get('payment_epoint_order_status_id');
$data['payment_epoint_status'] = $this->config->get('payment_epoint_status');


		$this->load->model('localisation/currency');

		$currencies = $this->model_localisation_currency->getCurrencies();
		$data['currencies'] = array();
		foreach ($currencies as $currency) {
			if (in_array($currency['code'], $this->currencies)) {
				$data['currencies'][] = array(
					'code'   => $currency['code'],
					'title'  => $currency['title']
				);
			}
		}



		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/epoint/payment/epoint', $data));
	}


	public function save():void {
		$this->load->language('extension/epoint/payment/epoint');
			$json = [];
			if (!$this->user->hasPermission('modify', 'extension/epoint/payment/epoint')) {
				$this->error['warning'] = $this->language->get('error_permission');
			}

			if (!$this->request->post['payment_epoint_currency']) {
				$this->error['error_currency'] = $this->language->get('error_currency');
			}

			if (!$this->request->post['payment_epoint_public_key']) {
				$this->error['error_public_key'] = $this->language->get('error_public_key');
			}

			if (!$this->request->post['payment_epoint_private_key']) {
				$this->error['error_private_key'] = $this->language->get('error_private_key');
			}

			$data['payment_epoint_public_key'] = $this->request->post['payment_epoint_public_key'];
			$data['payment_epoint_private_key'] = $this->request->post['payment_epoint_private_key'];
			$data['payment_epoint_language'] = $this->request->post['payment_epoint_language'];
			$data['payment_epoint_currency'] = $this->request->post['payment_epoint_currency'];
			$data['payment_epoint_order_status_id'] = $this->request->post['payment_epoint_order_status_id'];
			$data['payment_epoint_status'] = $this->request->post['payment_epoint_status'];


		if (!$json) {
			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting('payment_epoint', $this->request->post);

			$json['success'] = $this->language->get('text_success');
		}		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}