<?php
namespace Opencart\Admin\Model\Extension\Epoint\Payment;
class Epoint extends \Opencart\System\Engine\Model {
}